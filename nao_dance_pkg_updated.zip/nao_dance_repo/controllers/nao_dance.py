#!/usr/bin/env python3

# nao_dance.py
# Author: Fatima Jadoon
# Date: April 2026
#
# Webots Python controller for the NAO humanoid robot.
# Implements a choreographed dance routine in a stadium environment.
#
# The dance routine consists of 5 movements:
#
#   Movement 1 — Hand Wave (right arm)
#     The robot waves its right hand as an opening gesture.
#     Uses: HandWave.motion (pre-built)
#
#   Movement 2 — Tai Chi (both arms + legs + torso)
#     A slow flowing sequence involving both arms and legs simultaneously.
#     This is the most complex movement involving the most limbs.
#     Uses: TaiChi.motion (pre-built)
#
#   Movement 3 — Side Step Shuffle (both legs)
#     The robot steps left then right repeatedly in a shuffling dance move.
#     Involves both legs alternating weight transfer.
#     Uses: SideStepLeft.motion + SideStepRight.motion (pre-built, sequenced)
#
#   Movement 4 — Spin Turn (full body rotation)
#     The robot turns left 60 degrees then right 60 degrees twice,
#     creating a spinning dance effect involving the full body.
#     Uses: TurnLeft60.motion + TurnRight60.motion (pre-built, sequenced)
#
#   Movement 5 — Wipe and Shoot Finale (arms + legs)
#     The robot wipes its forehead then performs a kick/shoot motion
#     as a dramatic finale. Involves both arms and kicking leg.
#     Uses: WipeForehead.motion + Shoot.motion (pre-built, sequenced)
#
# DECLARATION:
#   All motion sequences use pre-built .motion files provided by
#   Cyberbotics/Webots for the NAO robot. These files contain
#   keyframe joint angle sequences validated on the real NAO robot.
#   The choreography, sequencing, timing, repetition logic, and
#   LED visual effects are original work by the author.
#
# The routine loops continuously so it can be recorded easily.

import sys
import os
import time
import csv
import math

WEBOTS_HOME = os.environ.get('WEBOTS_HOME', '/usr/local/webots')
sys.path.append(os.path.join(WEBOTS_HOME, 'lib', 'controller', 'python'))

from controller import Robot, Motion

# Path to the NAO motion files
MOTIONS_PATH = '../../motions/'

# How many times to repeat the full dance routine before stopping
# Set to 0 for infinite loop
REPEAT_COUNT = 3

# Where the per-run sensor log (CSV) and summary metrics get written
LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
BALANCE_FAIL_TILT_DEG = 15.0   # roll/pitch beyond this = treated as a balance failure


class NaoDance(Robot):
    """
    NAO robot dance controller.
    Plays a choreographed sequence of 5 movements involving
    multiple limbs simultaneously, using pre-built motion files.
    The routine includes arm waves, tai chi, side steps,
    spin turns, and a finale kick.
    """

    def __init__(self):
        super().__init__()
        self.time_step = int(self.getBasicTimeStep())

        print("=" * 55)
        print("NAO Dance Controller")
        print("Author: Fatima Jadoon")
        print("Routine: 5-movement Stadium Dance")
        print("=" * 55)

        # ---- Load all motion files ----
        self._load_motions()

        # ---- Initialise LEDs for visual effects ----
        self._init_leds()

        # ---- Initialise balance/coordination sensors ----
        self._init_sensors()

        # ---- State tracking ----
        self.currently_playing = None
        self.routine_count     = 0

        # ---- Measurement state (populated during the run, written to disk at the end) ----
        os.makedirs(LOG_DIR, exist_ok=True)
        self.sample_log = []          # one row per sensor sample: time, movement, roll, pitch, tilt
        self.movement_records = []    # one row per movement execution: measured duration, max tilt, fall flag, active joint count
        self.routine_records = []     # one row per full routine repetition: total duration, fall flag

        print("Controller ready. Starting dance routine...\n")

    # -----------------------------------------------------------------------
    # Sensor initialisation
    # -----------------------------------------------------------------------

    def _init_sensors(self):
        """
        Enable the NAO's inertial unit (roll/pitch/yaw) and gyroscope so that
        balance can be measured directly from sensor data rather than judged
        by eye. Falls back gracefully if a device isn't present in this NAO
        PROTO configuration.
        """
        self.sensors_ready = True
        try:
            self.inertial_unit = self.getDevice('inertial unit')
            self.inertial_unit.enable(self.time_step)
        except Exception:
            self.inertial_unit = None
            self.sensors_ready = False

        try:
            self.gyro = self.getDevice('gyro')
            self.gyro.enable(self.time_step)
        except Exception:
            self.gyro = None

        try:
            self.accelerometer = self.getDevice('accelerometer')
            self.accelerometer.enable(self.time_step)
        except Exception:
            self.accelerometer = None

        if self.sensors_ready:
            print("Sensors enabled: InertialUnit, Gyro, Accelerometer (balance logging active).")
        else:
            print("WARNING: InertialUnit not found — balance metrics will be unavailable.")

    def read_tilt_deg(self):
        """
        Returns (roll_deg, pitch_deg, combined_tilt_deg) from the inertial
        unit. Combined tilt is the magnitude of deviation from upright,
        used as the single balance-quality number for each movement.
        """
        if not self.sensors_ready:
            return 0.0, 0.0, 0.0
        roll, pitch, _yaw = self.inertial_unit.getRollPitchYaw()
        roll_deg = math.degrees(roll)
        pitch_deg = math.degrees(pitch)
        tilt_deg = math.sqrt(roll_deg ** 2 + pitch_deg ** 2)
        return roll_deg, pitch_deg, tilt_deg

    # -----------------------------------------------------------------------
    # Motion file loading
    # -----------------------------------------------------------------------

    def _load_motions(self):
        """
        Load all pre-built NAO motion files used in the dance routine.
        These are official Webots/Cyberbotics motion files containing
        validated joint angle keyframe sequences.
        """
        try:
            self.motion_handwave     = Motion(MOTIONS_PATH + 'HandWave.motion')
            self.motion_taichi       = Motion(MOTIONS_PATH + 'TaiChi.motion')
            self.motion_step_left    = Motion(MOTIONS_PATH + 'SideStepLeft.motion')
            self.motion_step_right   = Motion(MOTIONS_PATH + 'SideStepRight.motion')
            self.motion_turn_left    = Motion(MOTIONS_PATH + 'TurnLeft60.motion')
            self.motion_turn_right   = Motion(MOTIONS_PATH + 'TurnRight60.motion')
            self.motion_wipe         = Motion(MOTIONS_PATH + 'WipeForehead.motion')
            self.motion_shoot        = Motion(MOTIONS_PATH + 'Shoot.motion')
            self.motion_forwards     = Motion(MOTIONS_PATH + 'Forwards50.motion')

            print("Motion files loaded:")
            print("  HandWave, TaiChi, SideStepLeft, SideStepRight,")
            print("  TurnLeft60, TurnRight60, WipeForehead, Shoot, Forwards50")

        except Exception as e:
            print(f"Error loading motion files: {e}")
            sys.exit(1)

    # -----------------------------------------------------------------------
    # LED initialisation
    # -----------------------------------------------------------------------

    def _init_leds(self):
        """Initialise LEDs for visual dance effects."""
        try:
            self.chest_led  = self.getDevice('ChestBoard/Led')
            self.lfoot_led  = self.getDevice('LFoot/Led')
            self.rfoot_led  = self.getDevice('RFoot/Led')
            self.face_led_r = self.getDevice('Face/Led/Right')
            self.face_led_l = self.getDevice('Face/Led/Left')
            self.ear_led_r  = self.getDevice('Ears/Led/Right')
            self.ear_led_l  = self.getDevice('Ears/Led/Left')
            self.leds_ready = True
            print("LEDs initialised for visual effects.")
        except Exception:
            self.leds_ready = False
            print("LEDs not available — continuing without visual effects.")

    def set_leds(self, color):
        """Set all LEDs to a given RGB colour."""
        if not self.leds_ready:
            return
        try:
            self.chest_led.set(color)
            self.lfoot_led.set(color)
            self.rfoot_led.set(color)
            self.face_led_r.set(color)
            self.face_led_l.set(color)
            self.ear_led_r.set(color & 0xFF)
            self.ear_led_l.set(color & 0xFF)
        except Exception:
            pass

    def flash_leds(self, color1, color2, times=3):
        """Flash LEDs between two colours for visual effect."""
        for _ in range(times):
            self.set_leds(color1)
            self.wait(200)
            self.set_leds(color2)
            self.wait(200)

    # -----------------------------------------------------------------------
    # Motion control
    # -----------------------------------------------------------------------

    def play_motion(self, motion):
        """
        Start a motion, stopping any currently playing motion first.
        """
        if self.currently_playing and not self.currently_playing.isOver():
            self.currently_playing.stop()
        motion.play()
        self.currently_playing = motion

    def wait_for_motion(self, motion, movement_label="", sample_tag=""):
        """
        Block until the given motion finishes. Steps the simulation on each
        iteration and, on every step, samples the inertial unit so we get a
        real max-tilt figure for this motion instead of a visual impression.

        Returns (measured_duration_s, max_tilt_deg, fell_flag).
        """
        start_t = self.getTime()
        max_tilt = 0.0
        fell = False
        while not motion.isOver():
            if self.step(self.time_step) == -1:
                sys.exit(0)
            roll, pitch, tilt = self.read_tilt_deg()
            max_tilt = max(max_tilt, tilt)
            if tilt > BALANCE_FAIL_TILT_DEG:
                fell = True
            self.sample_log.append({
                'time_s': round(self.getTime(), 3),
                'movement': movement_label,
                'motion_file': sample_tag,
                'roll_deg': round(roll, 2),
                'pitch_deg': round(pitch, 2),
                'tilt_deg': round(tilt, 2),
            })
        duration = self.getTime() - start_t
        return duration, max_tilt, fell

    def count_active_joints(self, motion_filename):
        """
        Parses the raw .motion file (a plain CSV of joint angle keyframes)
        and counts how many joint columns actually change value by more than
        a small threshold across the keyframes. This gives a measured
        "N joints moved simultaneously" figure for each movement instead of
        an eyeballed limb description.
        """
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), MOTIONS_PATH, motion_filename)
        try:
            with open(path, 'r') as f:
                rows = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            if len(rows) < 2:
                return None
            header = rows[0].split(',')
            joint_names = [h.strip() for h in header[2:]]  # columns 0,1 are name/time
            mins = [float('inf')] * len(joint_names)
            maxs = [float('-inf')] * len(joint_names)
            for row in rows[1:]:
                fields = row.split(',')
                values = fields[2:]
                for i, v in enumerate(values):
                    v = v.strip()
                    if v == '' or i >= len(joint_names):
                        continue
                    try:
                        f_v = float(v)
                    except ValueError:
                        continue
                    mins[i] = min(mins[i], f_v)
                    maxs[i] = max(maxs[i], f_v)
            active = sum(1 for lo, hi in zip(mins, maxs) if hi - lo > 1.0)  # >1 degree of travel
            return active
        except Exception as e:
            print(f"  (could not parse {motion_filename} for joint count: {e})")
            return None

    def play_and_wait(self, motion, label="", movement_label=""):
        """Play a motion, wait for completion, and return measured metrics."""
        if label:
            print(f"  >> Playing: {label}")
        self.play_motion(motion)
        duration, max_tilt, fell = self.wait_for_motion(motion, movement_label=movement_label, sample_tag=label)
        active_joints = self.count_active_joints(label) if label else None
        joint_str = f", active_joints={active_joints}" if active_joints is not None else ""
        print(f"     measured: duration={duration:.2f}s, max_tilt={max_tilt:.2f}deg{joint_str}")
        return duration, max_tilt, fell, active_joints

    # -----------------------------------------------------------------------
    # Timing utility
    # -----------------------------------------------------------------------

    def wait(self, ms):
        """Wait for a given number of milliseconds in simulation time."""
        start = self.getTime()
        while self.getTime() - start < ms / 1000.0:
            if self.step(self.time_step) == -1:
                sys.exit(0)

    # -----------------------------------------------------------------------
    # Dance movements
    # -----------------------------------------------------------------------

    def movement_1_hand_wave(self):
        """
        Movement 1: Hand Wave
        The robot waves its right hand as an opening greeting gesture.
        Limbs involved: right arm (shoulder, elbow, wrist joints)
        Duration: ~3 seconds
        Pre-built motion: HandWave.motion
        """
        print("\n[MOVEMENT 1] Hand Wave — Opening greeting")
        self.set_leds(0x00FF00)  # green = friendly wave

        duration, max_tilt, fell, joints = self.play_and_wait(
            self.motion_handwave, "HandWave.motion", movement_label="Movement1_HandWave")
        self.movement_records.append({
            'routine': self.routine_count, 'movement': 'Movement1_HandWave',
            'duration_s': round(duration, 2), 'max_tilt_deg': round(max_tilt, 2),
            'fell': fell, 'active_joints': joints,
        })

        print("  Movement 1 complete.")

    def movement_2_tai_chi(self):
        """
        Movement 2: Tai Chi
        A slow, flowing sequence involving both arms, both legs, and the torso.
        This is the most expressive movement in the routine, demonstrating
        smooth coordinated multi-limb control.
        Limbs involved: both arms, both legs, torso rotation
        Duration: ~15 seconds
        Pre-built motion: TaiChi.motion
        """
        print("\n[MOVEMENT 2] Tai Chi — Flowing multi-limb sequence")
        self.set_leds(0x0000FF)  # blue = calm, flowing

        duration, max_tilt, fell, joints = self.play_and_wait(
            self.motion_taichi, "TaiChi.motion", movement_label="Movement2_TaiChi")
        self.movement_records.append({
            'routine': self.routine_count, 'movement': 'Movement2_TaiChi',
            'duration_s': round(duration, 2), 'max_tilt_deg': round(max_tilt, 2),
            'fell': fell, 'active_joints': joints,
        })

        print("  Movement 2 complete.")

    def movement_3_side_shuffle(self):
        """
        Movement 3: Side Step Shuffle
        The robot alternates stepping left and right three times,
        creating a classic dance shuffle. Both legs are involved
        in transferring weight and stepping sideways.
        Limbs involved: both legs, arms swing for balance
        Duration: ~9 seconds (3 left + 3 right steps)
        Pre-built motions: SideStepLeft.motion + SideStepRight.motion (sequenced)
        """
        print("\n[MOVEMENT 3] Side Step Shuffle — Alternating steps")
        self.set_leds(0xFF6600)  # orange = energetic shuffle

        total_duration, max_tilt, any_fell, joints = 0.0, 0.0, False, None
        # Three left-right shuffle cycles
        for i in range(3):
            print(f"  Shuffle cycle {i+1}/3...")
            d1, t1, f1, j1 = self.play_and_wait(
                self.motion_step_left, "SideStepLeft.motion", movement_label="Movement3_SideShuffle")
            d2, t2, f2, j2 = self.play_and_wait(
                self.motion_step_right, "SideStepRight.motion", movement_label="Movement3_SideShuffle")
            total_duration += d1 + d2
            max_tilt = max(max_tilt, t1, t2)
            any_fell = any_fell or f1 or f2
            joints = max(filter(None, [joints, j1, j2]), default=None)
        self.movement_records.append({
            'routine': self.routine_count, 'movement': 'Movement3_SideShuffle',
            'duration_s': round(total_duration, 2), 'max_tilt_deg': round(max_tilt, 2),
            'fell': any_fell, 'active_joints': joints,
        })

        print("  Movement 3 complete.")

    def movement_4_spin_turn(self):
        """
        Movement 4: Spin Turn
        The robot turns left 60 degrees then right 60 degrees twice,
        creating a spinning dance effect. Involves full-body rotation
        with both legs stepping and arms balancing.
        Limbs involved: both legs (stepping), both arms (balance), torso
        Duration: ~8 seconds
        Pre-built motions: TurnLeft60.motion + TurnRight60.motion (sequenced)
        """
        print("\n[MOVEMENT 4] Spin Turn — Full body rotation")
        self.flash_leds(0xFF0000, 0xFFFFFF, times=3)  # flash red/white = dramatic spin
        self.set_leds(0xFF0000)

        total_duration, max_tilt, any_fell, joints = 0.0, 0.0, False, None
        # Two spin cycles: left then right
        for i in range(2):
            print(f"  Spin cycle {i+1}/2...")
            d1, t1, f1, j1 = self.play_and_wait(
                self.motion_turn_left, "TurnLeft60.motion", movement_label="Movement4_SpinTurn")
            d2, t2, f2, j2 = self.play_and_wait(
                self.motion_turn_right, "TurnRight60.motion", movement_label="Movement4_SpinTurn")
            total_duration += d1 + d2
            max_tilt = max(max_tilt, t1, t2)
            any_fell = any_fell or f1 or f2
            joints = max(filter(None, [joints, j1, j2]), default=None)
        self.movement_records.append({
            'routine': self.routine_count, 'movement': 'Movement4_SpinTurn',
            'duration_s': round(total_duration, 2), 'max_tilt_deg': round(max_tilt, 2),
            'fell': any_fell, 'active_joints': joints,
        })

        print("  Movement 4 complete.")

    def movement_5_finale(self):
        """
        Movement 5: Wipe and Shoot Finale
        A two-part finale: the robot wipes its forehead (right arm + head tilt)
        then performs a dramatic kick/shoot motion (left leg kick + arm swing).
        Limbs involved: right arm, head, left leg, both arms
        Duration: ~6 seconds
        Pre-built motions: WipeForehead.motion + Shoot.motion (sequenced)
        """
        print("\n[MOVEMENT 5] Wipe and Shoot Finale — Grand finale!")
        self.flash_leds(0xFF00FF, 0xFFFF00, times=5)  # flash purple/yellow = finale!
        self.set_leds(0xFF00FF)

        d1, t1, f1, j1 = self.play_and_wait(
            self.motion_wipe, "WipeForehead.motion", movement_label="Movement5_Finale")
        self.wait(300)  # brief dramatic pause between the two finale moves
        d2, t2, f2, j2 = self.play_and_wait(
            self.motion_shoot, "Shoot.motion", movement_label="Movement5_Finale")
        self.movement_records.append({
            'routine': self.routine_count, 'movement': 'Movement5_Finale',
            'duration_s': round(d1 + d2, 2), 'max_tilt_deg': round(max(t1, t2), 2),
            'fell': f1 or f2, 'active_joints': max(filter(None, [j1, j2]), default=None),
        })

        # Victory flash at the end
        self.flash_leds(0xFFFFFF, 0x000000, times=5)
        self.set_leds(0x00FF00)

        print("  Movement 5 complete — Routine finished!")

    # -----------------------------------------------------------------------
    # Full dance routine
    # -----------------------------------------------------------------------

    def perform_routine(self):
        """
        Performs the complete 5-movement dance routine in sequence.
        Logs the start and end time of each movement.
        """
        self.routine_count += 1
        print(f"\n{'='*55}")
        print(f"DANCE ROUTINE — Performance {self.routine_count}")
        print(f"Time: {self.getTime():.1f}s")
        print(f"{'='*55}")

        # Opening LED sequence
        self.flash_leds(0xFF0000, 0x00FF00, times=3)
        self.wait(500)

        # Execute all 5 movements in sequence
        self.movement_1_hand_wave()
        self.wait(500)

        self.movement_2_tai_chi()
        self.wait(500)

        self.movement_3_side_shuffle()
        self.wait(500)

        self.movement_4_spin_turn()
        self.wait(500)

        self.movement_5_finale()
        self.wait(1000)

        routine_end_t = self.getTime()
        routine_records_this_run = [r for r in self.movement_records if r['routine'] == self.routine_count]
        routine_fell = any(r['fell'] for r in routine_records_this_run)
        routine_duration = sum(r['duration_s'] for r in routine_records_this_run)
        self.routine_records.append({
            'routine': self.routine_count,
            'measured_duration_s': round(routine_duration, 2),
            'fell': routine_fell,
        })

        print(f"\n[ROUTINE {self.routine_count}] Complete at t={routine_end_t:.1f}s "
              f"(measured active duration: {routine_duration:.2f}s, "
              f"balance failure: {routine_fell})")

    # -----------------------------------------------------------------------
    # Metrics export / summary
    # -----------------------------------------------------------------------

    def export_metrics(self):
        """
        Writes three CSV files to controllers/logs/ and prints a summary
        table of measured (not observed) results:
          - sensor_samples.csv   : raw tilt reading per simulation step
          - movement_metrics.csv : per-movement duration/tilt/joint counts
          - routine_summary.csv  : per-repetition pass/fail and duration

        Also prints aggregate statistics (mean, std dev, success rate) that
        can be quoted directly in the Results section of the report.
        """
        # --- raw samples ---
        samples_path = os.path.join(LOG_DIR, 'sensor_samples.csv')
        if self.sample_log:
            with open(samples_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=self.sample_log[0].keys())
                writer.writeheader()
                writer.writerows(self.sample_log)

        # --- per-movement metrics ---
        moves_path = os.path.join(LOG_DIR, 'movement_metrics.csv')
        if self.movement_records:
            with open(moves_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=self.movement_records[0].keys())
                writer.writeheader()
                writer.writerows(self.movement_records)

        # --- per-routine summary ---
        routine_path = os.path.join(LOG_DIR, 'routine_summary.csv')
        if self.routine_records:
            with open(routine_path, 'w', newline='') as f:
                writer = csv.DictWriter(f, fieldnames=self.routine_records[0].keys())
                writer.writeheader()
                writer.writerows(self.routine_records)

        # --- aggregate stats, printed for direct use in the report ---
        n_routines = len(self.routine_records)
        n_falls = sum(1 for r in self.routine_records if r['fell'])
        success_rate = 100.0 * (n_routines - n_falls) / n_routines if n_routines else 0.0

        print("\n" + "=" * 55)
        print("MEASURED RESULTS SUMMARY (from sensor logs)")
        print("=" * 55)
        print(f"Repetitions completed:      {n_routines}")
        print(f"Balance failures (tilt>{BALANCE_FAIL_TILT_DEG:.0f}deg): {n_falls}")
        print(f"Success rate:                {success_rate:.1f}%")

        by_movement = {}
        for r in self.movement_records:
            by_movement.setdefault(r['movement'], []).append(r)
        for name, recs in by_movement.items():
            durations = [x['duration_s'] for x in recs]
            tilts = [x['max_tilt_deg'] for x in recs]
            joints = [x['active_joints'] for x in recs if x['active_joints'] is not None]
            mean_d = sum(durations) / len(durations)
            std_d = (sum((d - mean_d) ** 2 for d in durations) / len(durations)) ** 0.5
            print(f"  {name:22s} n={len(recs):<2d} "
                  f"duration={mean_d:.2f}s (sd={std_d:.2f}s) "
                  f"max_tilt={max(tilts):.2f}deg "
                  f"active_joints={max(joints) if joints else 'n/a'}")
        print(f"\nLogs written to: {LOG_DIR}")
        print("=" * 55)

    # -----------------------------------------------------------------------
    # Main loop
    # -----------------------------------------------------------------------

    def run(self):
        """
        Main control loop. Performs the dance routine REPEAT_COUNT times.
        If REPEAT_COUNT is 0, loops indefinitely.
        """
        # Advance one step to initialise sensors
        if self.step(self.time_step) == -1:
            sys.exit(0)

        print("\n[INIT] NAO robot ready in stadium.")
        print(f"[INIT] Will perform {REPEAT_COUNT if REPEAT_COUNT > 0 else 'infinite'} "
              f"routine(s).\n")

        # Brief pause before starting
        self.wait(1000)

        count = 0
        while True:
            self.perform_routine()

            count += 1
            if REPEAT_COUNT > 0 and count >= REPEAT_COUNT:
                print(f"\n[DONE] All {REPEAT_COUNT} routines complete. Robot standing by.")
                self.export_metrics()
                self.set_leds(0xFFFFFF)
                # Keep simulation running
                while True:
                    if self.step(self.time_step) == -1:
                        sys.exit(0)

            # Brief pause between routines
            self.wait(2000)
            print("\n[REPEAT] Starting next routine...\n")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main():
    robot = NaoDance()
    robot.run()


if __name__ == '__main__':
    main()
